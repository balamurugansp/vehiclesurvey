package com.aconex.model;

public class VehicleEntryCreationException extends Exception {

    public VehicleEntryCreationException(String message) {
        super(message);
    }

}
