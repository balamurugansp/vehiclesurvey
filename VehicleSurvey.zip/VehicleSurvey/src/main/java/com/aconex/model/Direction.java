package com.aconex.model;

public enum Direction {
    SOUTH,NORTH
}
