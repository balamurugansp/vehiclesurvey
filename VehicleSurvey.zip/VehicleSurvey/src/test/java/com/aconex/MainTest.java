package com.aconex;

import org.junit.Test;

import static org.junit.Assert.*;

public class MainTest {

    @Test
    public void testMain() throws Exception {
        assertTrue(true);
    }
}